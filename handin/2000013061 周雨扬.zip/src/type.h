/* *
* @file types.h
* @brief define the constants used in the lab
*/

#ifndef MYTYPE_H
#define MYTYPE_H

typedef int (*frameReceiveCallback)(const void*, const void*, int, int);

#endif