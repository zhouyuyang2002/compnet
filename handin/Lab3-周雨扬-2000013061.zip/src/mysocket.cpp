#include "device.h"
#include "packetio.h"
#include "name2addr.h"
#include "callback.h"
#include "socket.h"
#include "ip.h"
#include <signal.h>
#include <pcap/pcap.h>

int __useless__func(){}